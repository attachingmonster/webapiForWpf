﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace webapiCodefirst.ViewModels
{
    public class ViewModelRegister
    {
        public String Account { get; set; }
        public String Password { get; set; }
        public String SurePassword { get; set; }
        public String Answer { get; set; }
        public String RememberPasswerd { get; set; }
        public String RoleName { get; set; }
    }
}
